// https://www.hackerrank.com/challenges/breaking-best-and-worst-records/problem
