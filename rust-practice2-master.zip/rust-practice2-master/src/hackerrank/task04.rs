// https://www.hackerrank.com/challenges/grading/problem
