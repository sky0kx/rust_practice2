// https://www.hackerrank.com/challenges/migratory-birds/problem
